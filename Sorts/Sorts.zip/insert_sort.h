#ifndef __INSERT_SORT_H__
#define __INSERT_SORT_H__

extern void insert_sort(int *array, int size, int *comps, int *swaps);

#endif /* __INSERT_SORT_H__ */
