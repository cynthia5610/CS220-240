#ifndef __QUICK_SORT_H__
#define __QUICK_SORT_H__

extern void quick_sort(int *array, int start, int end, int *comps, int *swaps);

#endif /* __QUICK_SORT_H__ */
