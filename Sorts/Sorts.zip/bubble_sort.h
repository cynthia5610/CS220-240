#ifndef __BUBBLE_SORT_H__
#define __BUBBLE_SORT_H__

extern void bubble_sort(int *array, int size, int *comps, int *swaps);

#endif /* __BUBBLE_SORT_H__ */
