#ifndef __SELECT_SORT_H__
#define __SELECT_SORT_H__

extern void select_sort(int *array, int size, int *comps, int *swaps);

#endif /* __SELECT_SORT_H__ */
