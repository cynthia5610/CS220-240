#ifndef __LINEAR_SEARCH_H__
#define __LINEAR_SEARCH_H__

#include <stdbool.h>

extern void linear_search(int *array, int size, int val, int *comps);

#endif /* __LINEAR_SEARCH_H__ */
