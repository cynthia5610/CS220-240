#ifndef __BINARY_SEARCH_H__
#define __BINARY_SEARCH_H__

#include <stdio.h>
#include <stdbool.h>

extern void binary_search(int *array, int size, int val, int *comps);

#endif /* __BINARY_SEARCH_H__ */
